package jrails;

public class View {

    public static Html empty() {
        return new Html();
    }//good

    public static Html br() {
        Html h = new Html( );
        return h.br();
    }//good

    public static Html t(Object o) {
        // Use o.toString() to get the text for this
        Html h = new Html( );
        return h.t(o);
    }//good

    public static Html p(Html child) {
        Html h = new Html( );
        return h.p(child);
    } //good

    public static Html div(Html child) {
        Html h = new Html( );
        return h.div(child);
    }//good

    public static Html strong(Html child) {
        Html h = new Html( );
        return h.strong(child);
    }//good

    public static Html h1(Html child) {
        Html h = new Html( );
        return h.h1(child);
    }//good

    public static Html tr(Html child) {
        Html h = new Html( );
        return h.tr(child);
    }//good

    public static Html th(Html child) {
        Html h = new Html( );
        return h.th(child);
    }//good

    public static Html td(Html child) {
        Html h = new Html( );
        return h.td(child);
    }//good

    public static Html table(Html child) {
        Html h = new Html( );
        return h.table(child);
    }//good

    public static Html thead(Html child) {
        Html h = new Html( );
        return h.thead(child);
    }//good

    public static Html tbody(Html child) {
        Html h = new Html( );
        return h.tbody(child);
    }//good

    public static Html textarea(String name, Html child) {
        Html h = new Html( );
        return h.textarea(name, child);
    }//good

    public static Html link_to(String text, String url) {
        Html h = new Html( );
        return h.link_to(text, url);
    }//good

    public static Html form(String action, Html child) {
        Html h = new Html( );
        return h.form(action, child);
    }//good

    public static Html submit(String value) {
        Html h = new Html( );
        return h.submit(value);
    }//good
}
